package com.anubhab.user.bo;

public interface Student{
 
	public String getMessage();
 
}