package com.anubhab.user.bo.impl;

import javax.inject.Named;

import com.anubhab.user.bo.Student;

@Named
public class StudentImplementation implements Student{
 
	public String getMessage() {
		
		return "This is a concrete Student";
	
	}
	
 
}